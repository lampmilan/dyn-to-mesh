bl_info = {
    "name": "Dyn to Mesh",
    "description": "Connect dynamic setup to high-res geo",
    "version": (1, 0, 0),
    "author": 'Milan Lampert "PapiTheArtist" ',
    "blender": (2, 80, 00),
    "warning": 'Use "dyn." and "render." / "highres." prefixs in the objects for proper working',
    "category": "Object",
}

import bpy

class DynToMesh(bpy.types.Operator):
    bl_idname = "cloth.copy_highres"
    bl_label = "Dyn to Mesh"

    def execute(self, context):

        so = bpy.context.active_object

        # Calculate the dynamic object name
        selected_geo = [obj.name for obj in bpy.context.selected_objects]
        raw_name = selected_geo[0].split(".")[1]
        dyn_geo = bpy.data.objects["dyn." + raw_name]

        # Add modifiers
        so.modifiers.new("Dyn To Mesh", "SURFACE_DEFORM")
        so.modifiers.new("Cloth Smooth", "CORRECTIVE_SMOOTH")
        so.modifiers.new("Cloth Thickness", "SOLIDIFY")
        so.modifiers["Dyn To Mesh"].target = dyn_geo

        return {'FINISHED'}


def register():
    bpy.utils.register_class(DynToMesh)


def unregister():
    bpy.utils.unregister_class(DynToMesh)


if __name__ == "__main__":
    register()